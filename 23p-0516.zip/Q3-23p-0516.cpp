#include <stdio.h>
// Function to parse card rank
int parseRank(char rank) {
switch (rank) {
case '2': return 0;
case '3': return 1;
case '4': return 2;
case '5': return 3;
case '6': return 4;
case '7': return 5;
case '8': return 6;
case '9': return 7;
case 'T': return 8;
case 'J': return 9;
case 'Q': return 10;
case 'K': return 11;
case 'A': return 12;
default: return -1; // Invalid rank
}
}
// Function to parse card suit
int parseSuit(char suit) {
switch (suit) {
case 'C': return 0; // Clubs
case 'D': return 1; // Diamonds
case 'H': return 2; // Hearts
case 'S': return 3; // Spades
default: return -1; // Invalid suit
}
}
// Function to compare two cards
int compareCards(char firstRank, char firstSuit, char secondRank, char secondSuit) {
int firstValue = parseRank(firstRank);
int secondValue = parseRank(secondRank);
int firstSuitValue = parseSuit(firstSuit);
int secondSuitValue = parseSuit(secondSuit);
if (firstValue < 0 || secondValue < 0 || firstSuitValue < 0 || secondSuitValue < 0)
return 0; // Invalid cards
if (firstValue < secondValue)
return -1;
else if (firstValue > secondValue)
return 1;
else {
if (firstSuitValue < secondSuitValue)
return -1;
else if (firstSuitValue > secondSuitValue)
return 1;
else
return 0; // Equal cards
}
}
// Function to determine if a hand is a flush
int isFlush(char hand[][3]) {
int baseSuit = parseSuit(hand[0][1]); // Get the suit of the first card
for (int i = 1; i < 5; i++) {
if (parseSuit(hand[i][1]) != baseSuit) // Compare suits
return 0; // Not a flush
}
return 1; // Flush
}
// Function to compare two hands
int compareHands(char firstHand[][3], char secondHand[][3]) {
// Check if both hands are flushes
int firstFlush = isFlush(firstHand);
int secondFlush = isFlush(secondHand);
if (firstFlush && !secondFlush)
return 1;
else if (!firstFlush && secondFlush)
return -1;
else {
// Compare high cards if both hands are not flushes or both are flushes
for (int i = 4; i >= 0; i--) {
int cmp = compareCards(firstHand[i][0], firstHand[i][1], secondHand[i][0], secondHand[i][1]);
if (cmp != 0)
return cmp;
}
return 0; // Tie
}
}
int main() {
  // Player's hands
  char firstHand[5][3];
  char secondHand[5][3];
  // Input poker hands for Player 1
  printf("Enter the poker hands for Player 1 (e.g., 2C 3D 4H 5S 6C):\n");
  for (int i = 0; i < 5; i++) {
    for (int j = 0; j < 2; j++) {
      scanf(" %c", &firstHand[i][j]); // Notice the space before %c to skip leading whitespace
    }
    firstHand[i][2] = '\0'; // Null-terminate the string
  }
  // Input poker hands for Player 2
  printf("Enter the poker hands for Player 2 (e.g., 2C 3D 4H 5S 6C):\n");
   for (int i = 0; i < 5; i++) {
    for (int j = 0; j < 2; j++) {
      scanf(" %c", &secondHand[i][j]); // Notice the space before %c to skip leading whitespace
    }
    secondHand[i][2] = '\0'; // Null-terminate the string
  }
  int result = compareHands(firstHand, secondHand);
    // Output winner
    if (result > 0)
        printf("Player 1 wins!\n");
    else if (result < 0)
        printf("Player 2 wins!\n");
    else
        printf("It's a tie!\n");
    return 0;
}
