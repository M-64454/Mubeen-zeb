#include <stdio.h>
int largestsequence(int N) {
    int largestnumber = 0;
    int maxlength = 0; 
    for (int i = 1; i < N; i++) {
        int length = 1; 
        for (int n = i; n != 1; length++) {
            if (n % 2 == 0)
                n /= 2;
            else
                n = 3 * n + 1;
        }   
        // Check if the current sequence length is longer than the maximum length found so far
        if (length > maxlength) {
            maxlength = length;
            largestnumber = i;
        }
    }
    return largestnumber; // return the starting number with the largest collatz sequence
}
int main() {
    int N;
    printf("Enter the limit N: ");
    scanf("%d", &N);
    int largest = largestsequence(N); 
    printf("The starting number %d that produces the largest collatz sequence is: %d\n", N, largest);
    return 0;
}
